import HeaderNav from "../components/Header";

var share = {
	components:{
		HeaderNav
	},
	mounted:function(){
		this.$el.style.paddingTop = "44px";
	}
}

export default share;