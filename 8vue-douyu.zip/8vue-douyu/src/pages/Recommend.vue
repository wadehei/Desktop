<template>
	<div>
		<HeaderNav>推荐</HeaderNav>
	</div>
</template>

<script>
	import share from "./shareAttr.js";
	export default{
		
		mixins:[share],
	}
</script>

<style scoped>
	
</style>