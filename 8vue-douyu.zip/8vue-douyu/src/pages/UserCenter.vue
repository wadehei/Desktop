<template>
	<div>
		<HeaderNav>个人中心</HeaderNav>
	</div>
</template>

<script>
	import share from "./shareAttr.js";
	export default{
		mixins:[share],
	}
</script>

<style scoped>
	
</style>