/**
 * Created by hama on 2016/8/28.
 */
var app = angular.module('lzy',['ionic']);
app.controller('resh',function($scope){
    //滚动刷新
    $scope.items = [];
    var base = 1;
    $scope.doRefresh = function(){
      for(var i=0;i<10;i++,base++){
        $scope.items.unshift(['items ',base].join(""));
      }
      // Stop the ion-refresher from spinning
      $scope.$broadcast("scroll.refreshComplete");
    }
})
app.controller('tab',function($scope){
  $scope.dosometing  = function(){
    alert('我被切换了');
  }
})
app.controller('list',function($scope){
  $scope.delete_item = function(num){

  };
})
